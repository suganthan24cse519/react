import React from 'react'
import { Link } from 'react-router-dom' 

const header = () => {
  return (
    <div className="navbar">
        <ul>
            <li><Link to='/login'>Login</Link></li>
            <li><Link to='/signin'>SignIn</Link></li>
        </ul>
    </div>
  )
}

export default header
