// Login.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './login.css'
const Login = () => {

  

  return (
    <div className="login-container">
      <div className="login-banner">
        <p>Extra 5% OFF*</p>
        <p>Join us to grab more discounts + Free Shipping on First orders</p>
        <p>COUPON: NEW5CT</p>
      </div>
      <form className="login-form" >
        <h2>Log In/Register</h2>
        <input type="text" placeholder="Enter your Email-Id or Mobile No." required />
        <Link to='/register'>
        <button type="submit" className="login-button">
         SUBMIT
        </button>
        </Link>
        <p>New to FirstCry? <a href="/register">Register Here</a></p>
        <p>Or log-In with</p>
        <div className="social-login">
          <button type="button" className="google-login">G</button>
          <button type="button" className="facebook-login">F</button>
        </div>
        <p>By continuing, you agree to FirstCry's <a href="/terms">Terms of Use</a> and <a href="/privacy">Privacy Policy</a></p>
      </form>
    </div>
  );
};

export default Login;
