// HomePage.jsx
import React from 'react';
  // Adjust path if needed
import './homepage.css'; // Import the CSS file for styling

const HomePage = () => {
  return (
    <div className="homepage">
      {/* Navigation Bar */}
      <nav className="navbar">
        <div className="logo">Toy Marche</div>
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/">Shop By Category</a></li>
          <li><a href="/">Shop By Brands</a></li>
          <li><a href="/">Gift Shop</a></li>
          <li><a href="/">More</a></li>
        </ul>
        <div className="nav-right">
          <input type="text" placeholder="search by product" className="search-bar" />
          <button className="search-button">SEARCH</button>
          <div className="icon-links">
            <span className="cart-icon">🛒 0</span>
            <span className="wishlist-icon">❤️ 0</span>
          </div>
          <a href="/login" className="login-signup">Login | Signup</a>
        </div>
      </nav>

      {/* Promotional Banner */}
      <div className="promo-banner">
        <div className="banner-content">
          <h2>Diecast Cars</h2>
          <p>Level Up Your Game with Our Dazzling Collection of Handpicked Diecast Models</p>
          <button className="shop-now-button">SHOP NOW</button>
        </div>
        <div className="banner-image">
          <img src="your-image-url.jpg" alt="Diecast Cars" />
        </div>
      </div>

      {/* Other content goes here */}
    </div>
  );
};

export default HomePage;
