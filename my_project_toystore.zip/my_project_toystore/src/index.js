import React from 'react';
import ReactDOM from 'react-dom/client';  
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import Login from './login';
import Signup from './signup';
import HomePage from './homepage';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Signup />} />
        <Route path="/home" element={<HomePage />} />
      </Routes>
    </Router>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
