// Signup.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './signup.css'
const Signup = () => {
  
  return (
    <div className="signup-container">
      <h2>Sign Up</h2>
      <form className="signup-form" >
        <input type="text" placeholder="Enter your Email" required />
        <input type="password" placeholder="Enter your Password" required />
        <Link to='/home'>
        <button type="submit" className="signup-button" >
          SUBMIT
        </button>
        </Link>
      </form>
    </div>
  );
};

export default Signup;
